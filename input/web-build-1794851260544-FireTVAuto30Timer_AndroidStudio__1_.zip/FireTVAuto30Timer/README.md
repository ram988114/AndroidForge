# FireTV Auto 30 Minute Timer

## Behaviour
- Starts its foreground monitoring service after Fire TV sends `BOOT_COMPLETED`.
- Starts a 30-minute session at boot.
- Dynamically watches `ACTION_SCREEN_ON`; every wake starts a fresh 30-minute session.
- At expiry, sends Media Pause, returns to Home, and requests lock/sleep using Android AccessibilityService.
- The app does not need to be opened for later sessions.

## One-time setup after installation
Fire OS does not allow an ordinary sideloaded APK to perform Home/Lock silently without special user authorization. Open the app once and enable **Timer Control** in Accessibility settings. This is a one-time setup, not required at each boot/wake.

Also exclude the app from any app-killing/background restrictions exposed by your Fire OS build.

## Build in Android Studio
1. Extract this ZIP.
2. Open the `FireTVAuto30Timer` folder in Android Studio.
3. Let Android Studio install Android SDK 35 and sync Gradle.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Debug APK: `app/build/outputs/apk/debug/app-debug.apk`.
6. For a release APK, use **Build > Generate Signed Bundle / APK > APK**.

## Install through ADB
```bat
adb connect FIRE_TV_IP:5555
adb install -r app-debug.apk
```

After first launch, enable the accessibility service using the app's one-time setup button, then restart Fire TV and test with a temporarily shortened `SESSION_MS` if desired.

## Important Fire OS limitation
A standard non-root APK cannot switch off Wi-Fi or physically cut power. `GLOBAL_ACTION_LOCK_SCREEN` requires API 28 and may be altered or blocked by a specific Fire OS release. Media Pause and Home are attempted first. The app targets SDK 28 for broad Fire OS compatibility.
