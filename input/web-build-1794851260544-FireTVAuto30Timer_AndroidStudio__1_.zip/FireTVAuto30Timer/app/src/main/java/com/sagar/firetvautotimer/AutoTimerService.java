package com.sagar.firetvautotimer;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.IBinder;

public class AutoTimerService extends Service {
    static final String ACTION_BOOT = "com.sagar.firetvautotimer.BOOT";
    static final String ACTION_START = "com.sagar.firetvautotimer.START";
    static final String ACTION_CANCEL = "com.sagar.firetvautotimer.CANCEL";
    private static final String CHANNEL = "auto_timer_status";
    private BroadcastReceiver screenReceiver;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(30, buildNotification("Monitoring Fire TV sessions"));
        screenReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (Intent.ACTION_SCREEN_ON.equals(intent.getAction())) startFreshSession();
            }
        };
        registerReceiver(screenReceiver, new IntentFilter(Intent.ACTION_SCREEN_ON));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_BOOT : intent.getAction();
        if (ACTION_CANCEL.equals(action)) cancelSession();
        else if (ACTION_START.equals(action)) startFreshSession();
        else ensureSession();
        return START_STICKY;
    }

    private void ensureSession() {
        long end = TimerStore.prefs(this).getLong(TimerStore.END_AT, 0L);
        if (end <= System.currentTimeMillis()) startFreshSession();
        else scheduleAt(end);
    }

    private void startFreshSession() {
        long end = System.currentTimeMillis() + TimerStore.SESSION_MS;
        TimerStore.prefs(this).edit().putLong(TimerStore.END_AT, end).apply();
        scheduleAt(end);
        updateNotification("30-minute session running");
    }

    private void scheduleAt(long end) {
        AlarmManager alarm = (AlarmManager) getSystemService(ALARM_SERVICE);
        PendingIntent pi = alarmIntent();
        if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi);
        else alarm.setExact(AlarmManager.RTC_WAKEUP, end, pi);
    }

    private void cancelSession() {
        ((AlarmManager)getSystemService(ALARM_SERVICE)).cancel(alarmIntent());
        TimerStore.prefs(this).edit().remove(TimerStore.END_AT).apply();
        updateNotification("Timer paused; monitoring remains active");
    }

    private PendingIntent alarmIntent() {
        return PendingIntent.getBroadcast(this, 730, new Intent(this, AlarmReceiver.class), PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Automatic TV timer", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Keeps the automatic 30-minute session timer active");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private Notification buildNotification(String text) {
        PendingIntent open = PendingIntent.getActivity(this, 31, new Intent(this, MainActivity.class), PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setContentTitle("Auto 30 Minute Timer").setContentText(text)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setOngoing(true).setContentIntent(open).build();
    }

    private void updateNotification(String text) {
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(30, buildNotification(text));
    }

    @Override public void onDestroy() {
        if (screenReceiver != null) unregisterReceiver(screenReceiver);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
