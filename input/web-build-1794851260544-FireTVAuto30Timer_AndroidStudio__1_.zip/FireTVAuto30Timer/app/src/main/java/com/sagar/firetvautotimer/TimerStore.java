package com.sagar.firetvautotimer;

import android.content.Context;
import android.content.SharedPreferences;

final class TimerStore {
    static final String PREFS = "auto_timer";
    static final String END_AT = "end_at";
    static final long SESSION_MS = 30L * 60L * 1000L;
    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
    private TimerStore() {}
}
