package com.sagar.firetvautotimer;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        startMonitor();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER);
        root.setPadding(55, 35, 55, 35); root.setBackgroundColor(Color.rgb(16,24,32));
        TextView title = text("Automatic 30-Minute Timer", 31, Color.WHITE); root.addView(title);
        TextView info = text("The timer starts automatically at Fire TV boot and again whenever the device wakes. One-time setup: enable Timer Control below.", 21, Color.LTGRAY);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(800, LinearLayout.LayoutParams.WRAP_CONTENT); ip.setMargins(0,28,0,28); info.setLayoutParams(ip); root.addView(info);
        Button enable = button("ENABLE TIMER CONTROL (ONE TIME)");
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); root.addView(enable);
        Button restart = button("RESTART 30-MINUTE SESSION NOW");
        restart.setOnClickListener(v -> command(AutoTimerService.ACTION_START)); root.addView(restart);
        setContentView(root);
    }
    private void startMonitor() { command(AutoTimerService.ACTION_BOOT); }
    private void command(String action) {
        Intent i = new Intent(this, AutoTimerService.class); i.setAction(action);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }
    private TextView text(String s, int size, int color) { TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER);return t; }
    private Button button(String s) { Button b=new Button(this);b.setText(s);b.setTextSize(18);b.setFocusable(true);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(620,88);p.setMargins(0,10,0,10);b.setLayoutParams(p);return b; }
}
